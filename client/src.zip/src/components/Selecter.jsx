import styled from "styled-components";

const Selector = ({ searchType }) => {
  return (
    searchType === "location" && (
      <Container>
        {location.map((x, i) => (
          <Item onClick={getDataByLocation}>{location[i]}</Item>
        ))}
      </Container>
    )
  );
};

const location = [
  "인천",
  "서울",
  "경기",
  "강원",
  "충남",
  "충북",
  "대전",
  "경북",
  "경남",
  "대구",
  "울산",
  "부산",
  "전북",
  "광주",
  "전남",
  "제주",
];
//
const Container = styled.div`
  display: grid;
  grid-template-columns: 1fr 1fr 1fr 1fr;
  text-align: center;
  line-height:40px;

  width: 100%;
  background-color: white;
  border: 1px solid black;
  height:200px;
  z-index:9999;
`;

const Item = styled.div`
  border: 1px solid black;

  &:hover {
    background-color: lightgray;
  }
`;

const getDataByLocation = () => {
  
}

export default Selector;
