import { Outlet, useOutletContext } from "react-router-dom";
import styled from "styled-components";
import Header from "../components/Header";
import Footer from "../components/Footer";
import {useState} from 'react';

const Container = () => {

  const [contents, setContents] = useState([]);

  const [count, setCount] = useOutletContext([]);
  const increment = () => setCount(c=>c+1);

  return (
    <StyledContainer>
      <Outlet context={count}/>
    </StyledContainer>
  );
}

const StyledContainer = styled.main`
  padding: 0 5%;
  margin: 2% 0;
`;

const Layout = () => {
  return (
    <>
      <Header />
        <Container />
      <Footer />
    </>
  );
};

export default Layout;
